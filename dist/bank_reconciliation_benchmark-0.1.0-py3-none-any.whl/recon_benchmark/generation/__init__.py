"""Synthetic benchmark generation."""
