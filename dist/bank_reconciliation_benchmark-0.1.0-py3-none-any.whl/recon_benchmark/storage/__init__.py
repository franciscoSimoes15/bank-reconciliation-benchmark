"""Benchmark storage and serialization."""
