from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path

from recon_benchmark.models import MatchingMethod, Scenario


DEFAULT_SCENARIOS: tuple[Scenario, ...] = tuple(Scenario)
DEFAULT_METHODS: tuple[MatchingMethod, ...] = tuple(MatchingMethod)


@dataclass(frozen=True, slots=True)
class ExperimentConfig:
    cases_per_scenario: int = 100
    candidates_per_case: int = 10
    natural_negative_count: int = 6
    controlled_hard_negative_count: int = 3
    development_seed: int = 7
    evaluation_seeds: tuple[int, ...] = (42, 43, 44, 45, 46)
    amount_tolerance: Decimal = Decimal("0.10")
    date_tolerance_days: int = 3
    amount_similarity_absolute_scale: Decimal = Decimal("1.00")
    amount_similarity_relative_scale: Decimal = Decimal("0.01")
    date_similarity_scale_days: int = 30
    qgram_size: int = 3
    tie_epsilon: float = 1e-12
    scenarios: tuple[Scenario, ...] = DEFAULT_SCENARIOS
    methods: tuple[MatchingMethod, ...] = DEFAULT_METHODS

    def validate(self) -> None:
        if self.cases_per_scenario <= 0:
            raise ValueError("cases_per_scenario tem de ser positivo.")
        if self.natural_negative_count != 6:
            raise ValueError("O protocolo exige exatamente 6 natural negatives.")
        if self.controlled_hard_negative_count != 3:
            raise ValueError("O protocolo exige exatamente 3 controlled hard negatives.")
        expected_candidates = 1 + self.natural_negative_count + self.controlled_hard_negative_count
        if self.candidates_per_case != expected_candidates:
            raise ValueError(
                "O protocolo exige exatamente 10 candidatos: "
                "1 true + 6 natural negatives + 3 controlled hard negatives."
            )
        if not self.evaluation_seeds:
            raise ValueError("É necessária pelo menos uma evaluation seed.")
        if len(self.evaluation_seeds) != len(set(self.evaluation_seeds)):
            raise ValueError("As evaluation seeds não podem estar duplicadas.")
        if self.amount_tolerance < 0:
            raise ValueError("amount_tolerance não pode ser negativa.")
        if self.date_tolerance_days < 0:
            raise ValueError("date_tolerance_days não pode ser negativo.")
        if self.amount_similarity_absolute_scale <= 0:
            raise ValueError("amount_similarity_absolute_scale tem de ser positiva.")
        if self.amount_similarity_relative_scale <= 0:
            raise ValueError("amount_similarity_relative_scale tem de ser positiva.")
        if self.date_similarity_scale_days <= 0:
            raise ValueError("date_similarity_scale_days tem de ser positivo.")
        if self.qgram_size < 1:
            raise ValueError("qgram_size tem de ser >= 1.")
        if self.tie_epsilon < 0:
            raise ValueError("tie_epsilon não pode ser negativo.")
        if self.scenarios != DEFAULT_SCENARIOS:
            raise ValueError("O protocolo exige os oito cenários na ordem P0–P7.")
        if self.methods != DEFAULT_METHODS:
            raise ValueError("O protocolo exige M0–M4 e a ablation M4-D configurados.")

    def to_dict(self) -> dict[str, object]:
        return {
            "cases_per_scenario": self.cases_per_scenario,
            "candidates_per_case": self.candidates_per_case,
            "natural_negative_count": self.natural_negative_count,
            "controlled_hard_negative_count": self.controlled_hard_negative_count,
            "development_seed": self.development_seed,
            "evaluation_seeds": list(self.evaluation_seeds),
            "amount_tolerance": format(self.amount_tolerance, "f"),
            "date_tolerance_days": self.date_tolerance_days,
            "amount_similarity_absolute_scale": format(
                self.amount_similarity_absolute_scale, "f"
            ),
            "amount_similarity_relative_scale": format(
                self.amount_similarity_relative_scale, "f"
            ),
            "date_similarity_scale_days": self.date_similarity_scale_days,
            "qgram_size": self.qgram_size,
            "tie_epsilon": self.tie_epsilon,
            "scenarios": [scenario.value for scenario in self.scenarios],
            "methods": [method.value for method in self.methods],
        }


def load_config(path: str | Path | None = None) -> ExperimentConfig:
    if path is None:
        config = ExperimentConfig()
        config.validate()
        return config

    loaded: object = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(loaded, Mapping) or not all(isinstance(key, str) for key in loaded):
        raise ValueError("A configuração tem de ser um objeto JSON.")
    raw: Mapping[str, object] = loaded

    config = ExperimentConfig(
        cases_per_scenario=_integer(raw, "cases_per_scenario", 100),
        candidates_per_case=_integer(raw, "candidates_per_case", 10),
        natural_negative_count=_integer(raw, "natural_negative_count", 6),
        controlled_hard_negative_count=_integer(raw, "controlled_hard_negative_count", 3),
        development_seed=_integer(raw, "development_seed", 7),
        evaluation_seeds=tuple(
            _integer_value(seed, "evaluation_seeds")
            for seed in _list(raw, "evaluation_seeds", [42, 43, 44, 45, 46])
        ),
        amount_tolerance=_decimal(raw, "amount_tolerance", "0.10"),
        date_tolerance_days=_integer(raw, "date_tolerance_days", 3),
        amount_similarity_absolute_scale=_decimal(
            raw, "amount_similarity_absolute_scale", "1.00"
        ),
        amount_similarity_relative_scale=_decimal(
            raw, "amount_similarity_relative_scale", "0.01"
        ),
        date_similarity_scale_days=_integer(raw, "date_similarity_scale_days", 30),
        qgram_size=_integer(raw, "qgram_size", 3),
        tie_epsilon=_float(raw, "tie_epsilon", 1e-12),
        scenarios=tuple(
            Scenario(_string_value(item, "scenarios"))
            for item in _list(raw, "scenarios", [item.value for item in DEFAULT_SCENARIOS])
        ),
        methods=tuple(
            MatchingMethod(_string_value(item, "methods"))
            for item in _list(raw, "methods", [item.value for item in DEFAULT_METHODS])
        ),
    )
    config.validate()
    return config


def _integer(raw: Mapping[str, object], key: str, default: int) -> int:
    return _integer_value(raw.get(key, default), key)


def _integer_value(value: object, key: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool):
        raise ValueError(f"{key} tem de ser inteiro.")
    return value


def _decimal(raw: Mapping[str, object], key: str, default: str) -> Decimal:
    value = raw.get(key, default)
    if not isinstance(value, (str, int, float)) or isinstance(value, bool):
        raise ValueError(f"{key} tem de ser numérico.")
    return Decimal(str(value))


def _float(raw: Mapping[str, object], key: str, default: float) -> float:
    value = raw.get(key, default)
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise ValueError(f"{key} tem de ser numérico.")
    return float(value)


def _list(raw: Mapping[str, object], key: str, default: list[object]) -> list[object]:
    value = raw.get(key, default)
    if not isinstance(value, list):
        raise ValueError(f"{key} tem de ser uma lista.")
    return value


def _string_value(value: object, key: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{key} só pode conter texto.")
    return value
