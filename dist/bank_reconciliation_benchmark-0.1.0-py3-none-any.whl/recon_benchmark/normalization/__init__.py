"""Benchmark field normalization."""
